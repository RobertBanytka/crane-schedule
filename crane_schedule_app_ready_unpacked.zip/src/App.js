import React, { useState } from "react";

function App() {
  const [schedule, setSchedule] = useState([
    {
      project: "Projekt A",
      address: "Warszawa, ul. Prosta 12",
      operator: "Jan Kowalski, 500600700",
      backup: "Adam Nowak, 500700800",
      suggestion: "AI: Sprawdź pogodę na budowie",
    },
  ]);

  return (
    <div className="p-6 bg-gray-100 min-h-screen">
      <h1 className="text-2xl font-bold mb-4">📅 Harmonogram pracy żurawia</h1>

      {schedule.map((item, index) => (
        <div key={index} className="bg-white p-4 rounded-2xl shadow mb-4">
          <p><b>Projekt:</b> {item.project}</p>
          <p><b>Adres:</b> {item.address}</p>
          <p><b>Operator:</b> {item.operator}</p>
          <p><b>Zastępstwo:</b> {item.backup}</p>
          <p className="text-blue-600"><b>Propozycja AI:</b> {item.suggestion}</p>
        </div>
      ))}

      <button className="mt-4 px-4 py-2 bg-blue-500 text-white rounded-lg">
        ➕ Dodaj harmonogram
      </button>
    </div>
  );
}

export default App;